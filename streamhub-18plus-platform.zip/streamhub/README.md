# StreamHub SEO + Upload

Includes:
- Public video listing/search/upload
- SEO title, description, canonical metadata
- robots.txt
- Dynamic sitemap.xml including public video URLs

## Before launch
Replace `https://YOUR-DOMAIN.example/` in `public/index.html` and `public/robots.txt` if desired. The server also generates a dynamic sitemap using the live domain.

## Google indexing
After deployment:
1. Add your domain to Google Search Console.
2. Verify ownership.
3. Submit `https://YOUR-DOMAIN/sitemap.xml`.
4. Use URL Inspection and request indexing for the homepage.

Indexing is controlled by Google and is not guaranteed.
