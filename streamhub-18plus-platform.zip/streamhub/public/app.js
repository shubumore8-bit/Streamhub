const grid=document.querySelector('#grid'), search=document.querySelector('#search');
const modal=document.querySelector('#modal'), player=document.querySelector('#player');
const mtitle=document.querySelector('#mtitle'), mmeta=document.querySelector('#mmeta');
let activeCat='all';

async function load(){
 const p=new URLSearchParams();
 if(search.value.trim()) p.set('q',search.value.trim());
 if(activeCat!=='all') p.set('category',activeCat);
 const data=await fetch('/api/videos?'+p).then(r=>r.json());
 grid.innerHTML=data.length?data.map(v=>`
 <article class="card" data-id="${v.id}">
   <div class="thumb"><img src="${v.thumbnail}" loading="lazy"><span class="duration">${v.duration}</span></div>
   <h3>${esc(v.title)}</h3><div class="meta">${esc(v.creator)} · ${v.views} views</div>
 </article>`).join(''):'<p>No videos found.</p>';
 document.querySelectorAll('.card').forEach(c=>c.onclick=()=>openVideo(c.dataset.id));
}
async function openVideo(id){
 const v=await fetch('/api/videos/'+id).then(r=>r.json());
 player.src=v.video; mtitle.textContent=v.title; mmeta.textContent=`${v.creator} · ${v.views} views · ${v.category}`;
 modal.classList.remove('hidden'); player.play().catch(()=>{});
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
document.querySelector('#searchBtn').onclick=load;
search.addEventListener('keydown',e=>{if(e.key==='Enter')load()});
document.querySelectorAll('#cats button').forEach(b=>b.onclick=()=>{
 document.querySelectorAll('#cats button').forEach(x=>x.classList.remove('active'));b.classList.add('active');
 activeCat=b.dataset.cat;load();
});
document.querySelector('#close').onclick=()=>{player.pause();player.removeAttribute('src');modal.classList.add('hidden')};
modal.onclick=e=>{if(e.target===modal)document.querySelector('#close').click()};
load();

document.querySelector('#uploadBtn').onclick=()=>document.querySelector('#uploadPanel').classList.toggle('hidden');
document.querySelector('#uploadForm').onsubmit=async e=>{
 e.preventDefault(); const s=document.querySelector('#uploadStatus'); s.textContent='Uploading...';
 try{
  const r=await fetch('/api/upload',{method:'POST',body:new FormData(e.target)});
  const d=await r.json(); if(!r.ok) throw new Error(d.error||'Upload failed');
  s.textContent=' Uploaded!'; e.target.reset(); load();
 }catch(err){s.textContent=' '+err.message}
};
