const express=require('express');
const multer=require('multer');
const path=require('path');
const fs=require('fs');
const crypto=require('crypto');
const app=express(), PORT=process.env.PORT||3000;
const DATA=path.join(__dirname,'data','videos.json');
const PUBLIC=path.join(__dirname,'public');
const INDEX=path.join(PUBLIC,'index.html');
const UP=path.join(__dirname,'uploads');
fs.mkdirSync(UP,{recursive:true});

const storage=multer.diskStorage({
 destination:(_,__,cb)=>cb(null,UP),
 filename:(_,file,cb)=>cb(null,Date.now()+"-"+crypto.randomBytes(6).toString("hex")+path.extname(file.originalname).toLowerCase())
});
const upload=multer({
 storage,
 limits:{fileSize:2*1024*1024*1024},
 fileFilter:(_,file,cb)=>cb(null,/^video\/(mp4|webm|quicktime|x-matroska)/i.test(file.mimetype))
});

app.use(express.json());
app.use((req,res,next)=>{
  const cookies=Object.fromEntries(String(req.headers.cookie||'').split(';').filter(Boolean).map(x=>{const i=x.indexOf('=');return [x.slice(0,i).trim(),decodeURIComponent(x.slice(i+1))]}));
  req.cookies=cookies;

  // Adult-only gate: visitors must explicitly confirm they are 18+.
  if(req.path.startsWith('/api/') || req.path.startsWith('/uploads/') || req.path==='/robots.txt' || req.path==='/sitemap.xml' || req.path==='/age-check' || req.path==='/admin') return next();
  if(req.cookies?.adult_ok !== '1' && req.path !== '/') return res.redirect('/');
  next();
});
app.use(express.static(PUBLIC));
app.use('/uploads',express.static(UP));

function read(){return JSON.parse(fs.readFileSync(DATA,'utf8'))}
function write(x){fs.writeFileSync(DATA,JSON.stringify(x,null,2))}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function baseUrl(req){return (process.env.SITE_URL||(`${req.protocol}://${req.get('host')}`)).replace(/\/$/,'')}
function absolute(req,u){if(/^https?:\/\//i.test(u||''))return u; const x=String(u||'/'); return baseUrl(req)+(x.startsWith('/')?x:'/'+x);}
function isoDuration(value){
 const m=String(value||'').match(/^(?:(\d+):)?(\d+):(\d+)$/); if(!m)return undefined;
 const h=Number(m[1]||0), min=Number(m[2]), sec=Number(m[3]); return `PT${h?`${h}H`:''}${min?`${min}M`:''}${sec?`${sec}S`:''}`;
}
function layout(req, {title,description,url,body,structuredData}={}){
 let html=fs.readFileSync(INDEX,'utf8');
 html=html.replace(/<title>[\s\S]*?<\/title>/i,`<title>${esc(title)}</title>`)
  .replace(/<meta name="description"[^>]*>/i,`<meta name="description" content="${esc(description)}">`)
  .replace(/<link rel="canonical"[^>]*>/i,`<link rel="canonical" href="${esc(url)}">`)
  .replace(/<meta property="og:title"[^>]*>/i,`<meta property="og:title" content="${esc(title)}">`)
  .replace(/<meta property="og:description"[^>]*>/i,`<meta property="og:description" content="${esc(description)}">`)
  .replace(/<meta property="og:url"[^>]*>/i,`<meta property="og:url" content="${esc(url)}">`);
 if(structuredData) html=html.replace('</head>',`<script type="application/ld+json">${JSON.stringify(structuredData).replace(/</g,'\\u003c')}</script></head>`);
 if(body) html=html.replace('<main>',`<main>${body}`);
 return html;
}

app.get('/api/videos',(req,res)=>{
 let a=read(),q=String(req.query.q||'').toLowerCase(),c=String(req.query.category||'').toLowerCase();
 if(q)a=a.filter(v=>(v.title+' '+v.creator+' '+(v.tags||[]).join(' ')).toLowerCase().includes(q));
 if(c&&c!=='all')a=a.filter(v=>v.category.toLowerCase()===c);
 res.json(a);
});

app.get('/sitemap.xml',(req,res)=>{
 const base=baseUrl(req), urls=[`<url><loc>${esc(base)}/</loc><changefreq>daily</changefreq><priority>1.0</priority></url>`];
 for(const v of read()) urls.push(`<url><loc>${esc(base+'/video/'+encodeURIComponent(v.id))}</loc><changefreq>weekly</changefreq><priority>0.7</priority></url>`);
 res.type('application/xml').send('<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+urls.join('')+'</urlset>');
});

app.get('/robots.txt',(req,res)=>res.type('text/plain').send(`User-agent: *\nAllow: /\nDisallow: /api/\nDisallow: /uploads/\nSitemap: ${baseUrl(req)}/sitemap.xml\n`));

app.get('/api/videos/:id',(req,res)=>{
 const v=read().find(x=>x.id===req.params.id); v?res.json(v):res.status(404).json({error:'Not found'});
});

app.get('/admin',(req,res)=>{res.send(fs.readFileSync(path.join(PUBLIC,'admin.html'),'utf8'))});

app.post('/api/upload',upload.single('video'),(req,res)=>{
 if(!process.env.ADMIN_TOKEN || req.headers['x-admin-token']!==process.env.ADMIN_TOKEN) return res.status(401).json({error:'Unauthorized'});
 if(!req.file)return res.status(400).json({error:'Choose a video file'});
 const list=read(),v={
   id:crypto.randomUUID(),title:req.body.title||req.file.originalname,
   creator:req.body.creator||'User',category:req.body.category||'General',
   duration:'',views:'0',likes:0,tags:String(req.body.tags||'').split(',').map(x=>x.trim()).filter(Boolean),
   thumbnail:'',video:'/uploads/'+req.file.filename,createdAt:new Date().toISOString()
 };
 list.unshift(v);write(list);res.json({ok:true,video:v});
});

app.get('/age-check',(req,res)=>{res.setHeader('Set-Cookie','adult_ok=1; Max-Age=86400; Path=/; SameSite=Lax'); res.redirect('/')});

app.get('/',(req,res)=>{
 const url=baseUrl(req)+'/', title='StreamHub — Discover & Watch Videos', description='Discover, search and watch videos from creators on StreamHub.';
 res.send(layout(req,{title,description,url,structuredData:{'@context':'https://schema.org','@type':'WebSite',name:'StreamHub',url,potentialAction:{'@type':'SearchAction',target:`${baseUrl(req)}/?q={search_term_string}`, 'query-input':'required name=search_term_string'}}}));
});

app.get('/video/:id',(req,res)=>{
 const v=read().find(x=>x.id===req.params.id); if(!v)return res.status(404).send(layout(req,{title:'Video not found | StreamHub',description:'The requested video could not be found.',url:baseUrl(req)+'/video/'+encodeURIComponent(req.params.id)}));
 const url=baseUrl(req)+'/video/'+encodeURIComponent(v.id), title=`${v.title} | StreamHub`, description=`Watch ${v.title} by ${v.creator} on StreamHub. Category: ${v.category}.`;
 const body=`<article class="video-page"><p><a href="/">← Back to StreamHub</a></p><h1>${esc(v.title)}</h1><p class="meta">${esc(v.creator)} · ${esc(v.category)} · ${esc(v.views)} views</p><video controls playsinline preload="metadata" src="${esc(absolute(req,v.video))}"${v.thumbnail?` poster="${esc(absolute(req,v.thumbnail))}"`:''}></video><p>${esc((v.tags||[]).map(t=>'#'+t).join(' '))}</p></article>`;
 const data={'@context':'https://schema.org','@type':'VideoObject',name:v.title,description,contentUrl:absolute(req,v.video),embedUrl:url,thumbnailUrl:v.thumbnail?[absolute(req,v.thumbnail)]:undefined,uploadDate:v.createdAt||undefined,duration:isoDuration(v.duration),publisher:{'@type':'Organization',name:'StreamHub'}};
 Object.keys(data).forEach(k=>data[k]===undefined&&delete data[k]);
 res.send(layout(req,{title,description,url,body,structuredData:data}));
});

app.listen(PORT,()=>console.log(`http://localhost:${PORT}`));
